"""
DECEPTICON — Bounty Recon Module
Subdomain enumeration + endpoint discovery for bug bounty targets.

Tools wrapped:
  subfinder, httpx, waybackurls, gau, ffuf, katana, arjun (via subprocess)
  crt.sh, SecurityTrails (via HTTP API)
"""

import asyncio
import json
import re
import subprocess
import shlex
import os
from datetime import datetime
from typing import Optional
import requests


# ──────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────

def _run(cmd: str, timeout: int = 120) -> dict:
    try:
        r = subprocess.run(shlex.split(cmd), capture_output=True, text=True, timeout=timeout)
        return {"stdout": r.stdout, "stderr": r.stderr,
                "success": r.returncode == 0, "returncode": r.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": f"Timed out ({timeout}s)", "success": False, "returncode": -1}
    except FileNotFoundError as e:
        return {"stdout": "", "stderr": f"Tool not found: {e}", "success": False, "returncode": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "success": False, "returncode": -1}


def _clean_lines(text: str) -> list[str]:
    return [l.strip() for l in text.strip().split("\n") if l.strip()]


# ──────────────────────────────────────────────────────────────────────
# 1. SUBDOMAIN DISCOVERY
# ──────────────────────────────────────────────────────────────────────

class SubdomainDiscovery:
    """
    Multi-source subdomain enumeration.
    Combines: subfinder + crt.sh + wayback
    """

    def __init__(self, domain: str):
        self.domain  = domain
        self.results = set()

    def run_subfinder(self) -> list[str]:
        """Fast passive subdomain enumeration."""
        r = _run(f"subfinder -d {self.domain} -silent -all", timeout=60)
        subs = _clean_lines(r["stdout"]) if r["success"] else []
        self.results.update(subs)
        return subs

    def run_crtsh(self) -> list[str]:
        """Certificate Transparency log search via crt.sh."""
        try:
            resp = requests.get(
                f"https://crt.sh/?q=%.{self.domain}&output=json",
                timeout=15
            )
            data = resp.json()
            subs = set()
            for entry in data:
                names = entry.get("name_value", "").split("\n")
                for name in names:
                    name = name.strip().lstrip("*.")
                    if name.endswith(self.domain) and "*" not in name:
                        subs.add(name)
            self.results.update(subs)
            return list(subs)
        except Exception as e:
            return []

    def run_wayback_subs(self) -> list[str]:
        """Extract subdomains from Wayback Machine URLs."""
        try:
            resp = requests.get(
                f"http://web.archive.org/cdx/search/cdx"
                f"?url=*.{self.domain}&output=text&fl=original&collapse=urlkey",
                timeout=20
            )
            subs = set()
            domain_pattern = re.compile(r'https?://([a-zA-Z0-9\-\.]+\.' + re.escape(self.domain) + r')')
            for match in domain_pattern.finditer(resp.text):
                sub = match.group(1)
                if "*" not in sub:
                    subs.add(sub)
            self.results.update(subs)
            return list(subs)
        except Exception:
            return []

    def resolve_live(self, subdomains: list[str]) -> list[dict]:
        """Probe subdomains to find live HTTP services."""
        if not subdomains:
            return []

        # Write temp file
        tmp = f"/tmp/subs_{self.domain.replace('.','_')}.txt"
        with open(tmp, "w") as f:
            f.write("\n".join(subdomains))

        r = _run(
            f"httpx -l {tmp} -status-code -title -tech-detect "
            f"-follow-redirects -content-length -web-server "
            f"-json -silent",
            timeout=120
        )

        live = []
        for line in _clean_lines(r["stdout"]):
            try:
                data = json.loads(line)
                live.append({
                    "url":         data.get("url", ""),
                    "host":        data.get("host", ""),
                    "ip":          data.get("a", [""])[0] if data.get("a") else "",
                    "status":      data.get("status-code", 0),
                    "title":       data.get("title", ""),
                    "tech":        data.get("tech", []),
                    "server":      data.get("webserver", ""),
                    "content_len": data.get("content-length", 0),
                    "interesting": self._is_interesting(data),
                })
            except json.JSONDecodeError:
                continue

        try:
            os.remove(tmp)
        except Exception:
            pass

        return live

    def _is_interesting(self, data: dict) -> bool:
        interesting_words = ["admin","api","login","dashboard","dev","staging",
                             "test","internal","portal","manage","cms","gitlab",
                             "jenkins","jira","confluence","grafana","kibana"]
        url   = data.get("url","").lower()
        title = data.get("title","").lower()
        return any(w in url or w in title for w in interesting_words)

    def check_takeover(self, subdomains: list[str]) -> list[dict]:
        """Check for subdomain takeover vulnerabilities via dangling CNAMEs."""
        # CNAME fingerprints for takeover-vulnerable services
        takeover_signatures = {
            "amazonaws.com":       "NoSuchBucket",
            "github.io":           "There isn't a GitHub Pages site here",
            "heroku.com":          "No such app",
            "pantheonsite.io":     "404 error unknown site",
            "shopify.com":         "Sorry, this shop is currently unavailable",
            "unbounce.com":        "The requested URL was not found",
            "zendesk.com":         "Help Center Closed",
            "readme.io":           "Project doesnt exist",
            "surge.sh":            "project not found",
            "bitbucket.io":        "Repository not found",
            "azurewebsites.net":   "404 Web Site not found",
            "cloudfront.net":      "ERROR: The request could not be satisfied",
        }

        vulnerable = []
        for sub in subdomains:
            try:
                import socket
                ip = socket.gethostbyname(sub)
            except socket.gaierror:
                # Can't resolve — potential CNAME dangling
                try:
                    r = _run(f"dig CNAME {sub} +short", timeout=5)
                    cname = r["stdout"].strip()
                    if cname:
                        for service, _ in takeover_signatures.items():
                            if service in cname:
                                vulnerable.append({
                                    "subdomain": sub,
                                    "cname":     cname,
                                    "service":   service,
                                    "type":      "UNRESOLVABLE_CNAME",
                                    "severity":  "HIGH",
                                })
                except Exception:
                    pass

        return vulnerable

    def run_all(self) -> dict:
        """Run complete subdomain discovery pipeline."""
        ts = datetime.now().isoformat()

        print(f"[SCOUT] Running subfinder for {self.domain}...")
        subfinder_subs = self.run_subfinder()

        print(f"[SCOUT] Querying crt.sh...")
        crtsh_subs = self.run_crtsh()

        print(f"[SCOUT] Querying Wayback Machine...")
        wayback_subs = self.run_wayback_subs()

        all_subs = list(self.results)
        print(f"[SCOUT] Found {len(all_subs)} unique subdomains. Probing for live hosts...")

        live_hosts = self.resolve_live(all_subs)
        takeovers  = self.check_takeover(all_subs)

        return {
            "domain":          self.domain,
            "timestamp":       ts,
            "total_found":     len(all_subs),
            "live_count":      len(live_hosts),
            "all_subdomains":  all_subs,
            "live_hosts":      live_hosts,
            "interesting_hosts": [h for h in live_hosts if h["interesting"]],
            "potential_takeovers": takeovers,
            "sources": {
                "subfinder": len(subfinder_subs),
                "crtsh":     len(crtsh_subs),
                "wayback":   len(wayback_subs),
            }
        }


# ──────────────────────────────────────────────────────────────────────
# 2. ENDPOINT DISCOVERY
# ──────────────────────────────────────────────────────────────────────

class EndpointDiscovery:
    """
    Deep endpoint discovery for a live target URL.
    Combines: waybackurls, gau, ffuf, katana, JS analysis.
    """

    # High-priority paths to always check
    PRIORITY_PATHS = [
        "/.git/HEAD", "/.env", "/.env.local", "/.env.production",
        "/config.json", "/config.yaml", "/config.php",
        "/api/v1/", "/api/v2/", "/api/v3/",
        "/graphql", "/graphiql", "/playground",
        "/swagger.json", "/swagger.yaml", "/openapi.json", "/api-docs",
        "/actuator", "/actuator/health", "/actuator/env", "/actuator/heapdump",
        "/admin", "/admin/", "/administrator",
        "/wp-admin", "/wp-login.php", "/wp-json/wp/v2/users",
        "/phpmyadmin", "/pma",
        "/.well-known/security.txt", "/robots.txt", "/sitemap.xml",
        "/backup", "/backup.zip", "/backup.tar.gz", "/db.sql",
        "/server-status", "/server-info",
        "/__debug__", "/debug", "/trace",
        "/console", "/rails/info/properties",
        "/.DS_Store",
    ]

    # Interesting parameter names
    JUICY_PARAMS = [
        "id", "user_id", "uid", "account_id",
        "file", "path", "filename", "dir",
        "url", "redirect", "next", "return",
        "token", "key", "api_key", "secret",
        "callback", "jsonp",
        "query", "search", "q",
        "cmd", "exec", "command",
        "debug", "test",
    ]

    def __init__(self, target_url: str):
        self.url    = target_url.rstrip("/")
        self.domain = re.sub(r"https?://", "", self.url).split("/")[0]

    def run_waybackurls(self) -> list[str]:
        """Fetch historical URLs from Wayback Machine."""
        r = _run(f"waybackurls {self.domain}", timeout=60)
        if r["success"]:
            urls = _clean_lines(r["stdout"])
            # Filter to same domain, deduplicate
            return list({u for u in urls if self.domain in u})
        return []

    def run_gau(self) -> list[str]:
        """GetAllURLs — fetch from multiple sources."""
        r = _run(
            f"gau {self.domain} --subs "
            f"--blacklist png,jpg,gif,css,woff,woff2,ttf,svg,ico",
            timeout=60
        )
        if r["success"]:
            return list({u.strip() for u in _clean_lines(r["stdout"]) if self.domain in u})
        return []

    def check_priority_paths(self) -> list[dict]:
        """Check high-value paths directly."""
        found = []
        for path in self.PRIORITY_PATHS:
            url = f"{self.url}{path}"
            try:
                resp = requests.get(url, timeout=5, allow_redirects=False,
                                    headers={"User-Agent": "Mozilla/5.0"})
                if resp.status_code in (200, 301, 302, 401, 403):
                    found.append({
                        "url":    url,
                        "status": resp.status_code,
                        "size":   len(resp.content),
                        "priority": self._path_priority(path, resp),
                    })
            except Exception:
                continue
        return found

    def _path_priority(self, path: str, resp) -> str:
        critical_paths = ["/.git", "/.env", "/actuator/heapdump",
                          "/actuator/env", "/graphql", "/swagger"]
        high_paths     = ["/admin", "/phpmyadmin", "/wp-admin",
                          "/api-docs", "/backup", "/db.sql"]
        for cp in critical_paths:
            if cp in path and resp.status_code == 200:
                return "CRITICAL"
        for hp in high_paths:
            if hp in path and resp.status_code in (200, 401):
                return "HIGH"
        return "MEDIUM"

    def run_ffuf(self, wordlist: str = "/usr/share/wordlists/dirb/common.txt") -> list[dict]:
        """Directory and file fuzzing with ffuf."""
        if not os.path.exists(wordlist):
            wordlist = "/usr/share/wordlists/dirb/big.txt"
        if not os.path.exists(wordlist):
            return []

        out_file = f"/tmp/ffuf_{self.domain.replace('.','_')}.json"
        r = _run(
            f"ffuf -w {wordlist} -u {self.url}/FUZZ "
            f"-mc 200,201,301,302,401,403,405 "
            f"-o {out_file} -of json -s",
            timeout=300
        )

        results = []
        try:
            with open(out_file) as f:
                data = json.load(f)
            for result in data.get("results", []):
                results.append({
                    "url":    result.get("url"),
                    "status": result.get("status"),
                    "size":   result.get("length"),
                    "words":  result.get("words"),
                })
            os.remove(out_file)
        except Exception:
            pass

        return results

    def extract_js_endpoints(self) -> dict:
        """Extract endpoints and secrets from JavaScript files."""
        r = _run(f"katana -u {self.url} -jc -silent -depth 3", timeout=120)
        js_urls    = []
        endpoints  = []
        secrets    = []

        if r["success"]:
            all_urls = _clean_lines(r["stdout"])
            js_urls  = [u for u in all_urls if u.endswith(".js")]
            endpoints = [u for u in all_urls if "/api/" in u or "/v1/" in u or "/v2/" in u]

            # Scan each JS file for secrets
            for js_url in js_urls[:20]:  # limit to first 20 JS files
                try:
                    resp = requests.get(js_url, timeout=5,
                                        headers={"User-Agent": "Mozilla/5.0"})
                    content = resp.text

                    # AWS keys
                    aws = re.findall(r'AKIA[0-9A-Z]{16}', content)
                    for key in aws:
                        secrets.append({"type": "AWS_ACCESS_KEY", "value": key[:8]+"...", "file": js_url})

                    # Generic API keys
                    api_keys = re.findall(r'(?:api[_\-]?key|apikey|api_secret)["\s]*[:=]["\s]*([a-zA-Z0-9\-_]{20,})', content, re.IGNORECASE)
                    for key in api_keys:
                        secrets.append({"type": "API_KEY", "value": key[:10]+"...", "file": js_url})

                    # JWT tokens
                    jwts = re.findall(r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}', content)
                    for jwt in jwts:
                        secrets.append({"type": "JWT_TOKEN", "value": jwt[:20]+"...", "file": js_url})

                    # Bearer tokens
                    bearers = re.findall(r'Bearer\s+([a-zA-Z0-9\-_\.]{20,})', content)
                    for t in bearers:
                        secrets.append({"type": "BEARER_TOKEN", "value": t[:15]+"...", "file": js_url})

                    # Internal API endpoints
                    internal = re.findall(r'["\`](/(?:api|v\d|internal|admin|graphql)[^"\'`\s]{3,})["\`]', content)
                    for ep in internal:
                        if ep not in endpoints:
                            endpoints.append(ep)

                except Exception:
                    continue

        return {
            "js_files_found":  len(js_urls),
            "js_files_scanned": min(len(js_urls), 20),
            "endpoints_from_js": endpoints,
            "secrets_found":    secrets,
            "js_urls":          js_urls[:10],
        }

    def discover_parameters(self, endpoint: str) -> list[str]:
        """Discover hidden parameters in an endpoint using arjun."""
        r = _run(f"arjun -u {endpoint} --stable -q", timeout=120)
        params = []
        if r["success"]:
            param_match = re.findall(r'Parameter found: (\w+)', r["stdout"])
            params = param_match
        return params

    def run_all(self, run_ffuf: bool = True) -> dict:
        """Full endpoint discovery pipeline."""
        ts = datetime.now().isoformat()
        print(f"[SCOUT] Starting endpoint discovery for {self.url}...")

        print("[SCOUT] Checking priority paths...")
        priority = self.check_priority_paths()

        print("[SCOUT] Fetching from Wayback Machine + GAU...")
        wb_urls  = self.run_waybackurls()
        gau_urls = self.run_gau()

        print("[SCOUT] Extracting from JavaScript files...")
        js_data = self.extract_js_endpoints()

        all_urls = list(set(wb_urls + gau_urls + js_data.get("endpoints_from_js", [])))

        # Extract juicy parameters
        juicy_endpoints = []
        for url in all_urls:
            params = re.findall(r'[?&](\w+)=', url)
            interesting_params = [p for p in params if p.lower() in self.JUICY_PARAMS]
            if interesting_params:
                juicy_endpoints.append({
                    "url":    url,
                    "params": interesting_params,
                    "reason": f"Interesting parameter(s): {', '.join(interesting_params)}"
                })

        ffuf_results = []
        if run_ffuf:
            print("[SCOUT] Running ffuf directory fuzzing...")
            ffuf_results = self.run_ffuf()

        return {
            "target":             self.url,
            "timestamp":          ts,
            "priority_paths":     priority,
            "historical_urls":    len(all_urls),
            "juicy_endpoints":    juicy_endpoints[:50],
            "ffuf_results":       ffuf_results,
            "js_analysis":        js_data,
            "critical_findings":  [p for p in priority if p["priority"] == "CRITICAL"],
            "high_findings":      [p for p in priority if p["priority"] == "HIGH"],
            "summary": {
                "secrets_in_js":    len(js_data.get("secrets_found", [])),
                "exposed_paths":    len([p for p in priority if p["status"] == 200]),
                "juicy_params":     len(juicy_endpoints),
                "historical_urls":  len(all_urls),
            }
        }
