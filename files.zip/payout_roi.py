"""
DECEPTICON — Payout Estimator & ROI Tracker

PayoutEstimator  — Predicts bounty before submission
ROITracker       — Tracks earnings, acceptance rates, program performance
SubmissionQueue  — Prioritizes findings by expected_payout DESC
"""

import json
import csv
import os
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from typing import Optional


# ══════════════════════════════════════════════════════════════════════
# DATA MODELS
# ══════════════════════════════════════════════════════════════════════

@dataclass
class ProgramPayoutTable:
    """Payout ranges declared by a bug bounty program."""
    program_id:    str
    platform:      str
    program_name:  str
    critical_min:  int = 0
    critical_max:  int = 0
    high_min:      int = 0
    high_max:      int = 0
    medium_min:    int = 0
    medium_max:    int = 0
    low_min:       int = 0
    low_max:       int = 0
    info_min:      int = 0
    info_max:      int = 0
    # Extra metadata
    avg_response_days: int = 30
    payout_reputation: str = "AVERAGE"  # GENEROUS | AVERAGE | STINGY | UNKNOWN
    bonus_likelihood:  float = 0.0      # 0–1 chance of above-range bonus


@dataclass
class PayoutEstimate:
    finding_id:         str
    title:              str
    vuln_type:          str
    cvss_score:         float
    severity:           str
    triage_confidence:  float
    base_payout:        int
    multiplier:         float
    expected_payout:    int
    payout_min:         int
    payout_max:         int
    estimate_confidence: str  # HIGH | MEDIUM | LOW
    multipliers_applied: list[str] = field(default_factory=list)
    estimated_days_to_payout: int = 30
    roi_score:          float = 0.0


@dataclass
class SubmissionRecord:
    """One submitted report — updated as platform responds."""
    report_id:          str
    finding_id:         str
    title:              str
    platform:           str
    program_id:         str
    program_name:       str
    vuln_type:          str
    severity:           str
    cvss_score:         float
    submitted_at:       str
    status:             str = "new"  # new|triaged|resolved|duplicate|n/a
    estimated_payout:   int = 0
    actual_payout:      int = 0
    resolved_at:        Optional[str] = None
    days_to_resolve:    Optional[int] = None
    notes:              str = ""
    url:                str = ""


# ══════════════════════════════════════════════════════════════════════
# PAYOUT ESTIMATOR
# ══════════════════════════════════════════════════════════════════════

class PayoutEstimator:
    """
    Predicts bounty payout for a finding based on:
    - Program's stated payout table
    - Vulnerability type multipliers
    - Context (auth required, impact scope, novelty)
    """

    # Default industry payout ranges when program doesn't specify
    INDUSTRY_DEFAULTS = {
        "CRITICAL": (3000, 15000, 8000),   # (min, max, midpoint)
        "HIGH":     (1000,  5000, 2500),
        "MEDIUM":   ( 300,  1500,  600),
        "LOW":      (  50,   300,  100),
        "INFO":     (   0,    50,    0),
    }

    # Vuln type multipliers on base payout
    VULN_MULTIPLIERS = {
        "rce":                  1.80,
        "account_takeover":     1.70,
        "auth_bypass":          1.60,
        "ssrf":                 1.50,
        "sqli":                 1.45,
        "xxe":                  1.35,
        "privilege_escalation": 1.40,
        "open_s3_bucket":       1.30,
        "default_credentials":  1.25,
        "env_file_exposure":    1.35,
        "git_exposure":         1.20,
        "idor":                 1.15,
        "xss_stored":           1.10,
        "lfi":                  1.10,
        "path_traversal":       1.05,
        "xss_reflected":        0.85,
        "csrf":                 0.75,
        "open_redirect":        0.60,
        "info_disclosure":      0.50,
        "missing_headers":      0.20,
        "clickjacking":         0.20,
    }

    # Platform-level payout reputation
    PLATFORM_REPUTATION = {
        "hackerone": 1.05,   # Slightly above average
        "bugcrowd":  0.95,
        "intigriti": 1.10,   # Known for fair payouts
        "yeswehack": 1.00,
    }

    # Time to payout estimates (days) per platform + severity
    TIME_TO_PAYOUT = {
        ("hackerone", "CRITICAL"): 10,
        ("hackerone", "HIGH"):     21,
        ("hackerone", "MEDIUM"):   35,
        ("hackerone", "LOW"):      60,
        ("bugcrowd",  "CRITICAL"): 14,
        ("bugcrowd",  "HIGH"):     30,
        ("bugcrowd",  "MEDIUM"):   45,
        ("bugcrowd",  "LOW"):      75,
        ("intigriti", "CRITICAL"): 14,
        ("intigriti", "HIGH"):     25,
        ("intigriti", "MEDIUM"):   40,
        ("intigriti", "LOW"):      70,
        ("yeswehack", "CRITICAL"): 18,
        ("yeswehack", "HIGH"):     28,
        ("yeswehack", "MEDIUM"):   45,
        ("yeswehack", "LOW"):      70,
    }

    def estimate(self,
                 finding_id: str,
                 title: str,
                 vuln_type: str,
                 severity: str,
                 cvss_score: float,
                 triage_confidence: float,
                 platform: str,
                 program: ProgramPayoutTable,
                 context: dict = None) -> PayoutEstimate:
        """
        Generate a payout estimate for a finding.
        context = {auth_required, affects_all_users, novel_chain,
                   financial_data, production_impact}
        """
        context = context or {}
        multipliers_applied = []

        # Step 1: Base payout from program table
        sev_upper = severity.upper()
        base = self._get_base_payout(sev_upper, program)
        multipliers_applied.append(f"Base ({sev_upper}): ${base}")

        # Step 2: Vuln type multiplier
        vt_mult = self.VULN_MULTIPLIERS.get(vuln_type.lower(), 1.0)
        if vt_mult != 1.0:
            multipliers_applied.append(f"Vuln type ({vuln_type}): ×{vt_mult}")

        # Step 3: Context multipliers
        ctx_mult = 1.0
        if not context.get("auth_required", False):
            ctx_mult += 0.20
            multipliers_applied.append("+20% no auth required")
        if context.get("affects_all_users", False):
            ctx_mult += 0.25
            multipliers_applied.append("+25% affects all users")
        if context.get("financial_data", False):
            ctx_mult += 0.20
            multipliers_applied.append("+20% financial data")
        if context.get("novel_chain", False):
            ctx_mult += 0.15
            multipliers_applied.append("+15% novel attack chain")
        if context.get("production_impact", False):
            ctx_mult += 0.10
            multipliers_applied.append("+10% production impact")
        if context.get("requires_user_interaction", False):
            ctx_mult -= 0.25
            multipliers_applied.append("-25% requires user interaction")
        if context.get("single_user_only", False):
            ctx_mult -= 0.20
            multipliers_applied.append("-20% single user impact only")

        # Step 4: Platform reputation
        plt_mult = self.PLATFORM_REPUTATION.get(platform.lower(), 1.0)
        if program.payout_reputation == "GENEROUS":
            plt_mult *= 1.20
            multipliers_applied.append("+20% generous program")
        elif program.payout_reputation == "STINGY":
            plt_mult *= 0.75
            multipliers_applied.append("-25% program known for low payouts")

        # Step 5: Confidence-adjusted expectation
        total_mult   = vt_mult * ctx_mult * plt_mult
        raw_expected = int(base * total_mult)

        # Discount by triage confidence
        expected = int(raw_expected * triage_confidence)

        # Compute min/max range
        defaults = self.INDUSTRY_DEFAULTS.get(sev_upper, (0, 0, 0))
        pmin     = int(defaults[0] * triage_confidence)
        pmax     = int(defaults[1] * total_mult)

        # Estimate confidence
        if program.payout_reputation != "UNKNOWN" and program.critical_max > 0:
            est_conf = "HIGH"
        elif platform in ("hackerone", "bugcrowd"):
            est_conf = "MEDIUM"
        else:
            est_conf = "LOW"

        # Time to payout
        ttp = self.TIME_TO_PAYOUT.get(
            (platform.lower(), sev_upper),
            program.avg_response_days
        )

        # ROI score = expected_payout / days_to_payout
        roi = round(expected / max(ttp, 1), 1)

        return PayoutEstimate(
            finding_id=finding_id,
            title=title,
            vuln_type=vuln_type,
            cvss_score=cvss_score,
            severity=severity,
            triage_confidence=triage_confidence,
            base_payout=base,
            multiplier=round(total_mult, 2),
            expected_payout=expected,
            payout_min=pmin,
            payout_max=pmax,
            estimate_confidence=est_conf,
            multipliers_applied=multipliers_applied,
            estimated_days_to_payout=ttp,
            roi_score=roi,
        )

    def _get_base_payout(self, severity: str, program: ProgramPayoutTable) -> int:
        """Get midpoint of program's stated range, or industry default."""
        ranges = {
            "CRITICAL": (program.critical_min, program.critical_max),
            "HIGH":     (program.high_min,     program.high_max),
            "MEDIUM":   (program.medium_min,   program.medium_max),
            "LOW":      (program.low_min,       program.low_max),
            "INFO":     (program.info_min,      program.info_max),
        }
        mn, mx = ranges.get(severity, (0, 0))
        if mx > 0:
            return int((mn + mx) / 2)
        # Fall back to industry default midpoint
        return self.INDUSTRY_DEFAULTS.get(severity, (0, 0, 0))[2]

    def rank_programs(self, programs: list[ProgramPayoutTable]) -> list[dict]:
        """Score and rank programs by ROI potential."""
        ranked = []
        for p in programs:
            score = 0

            # Payout score (0–40)
            if p.critical_max >= 10000: score += 40
            elif p.critical_max >= 5000: score += 30
            elif p.critical_max >= 2000: score += 20
            elif p.critical_max >= 1000: score += 10
            else: score += 5

            # Reputation (0–20)
            rep_scores = {"GENEROUS": 20, "AVERAGE": 10, "STINGY": 2, "UNKNOWN": 5}
            score += rep_scores.get(p.payout_reputation, 5)

            # Response time (0–20) — faster = better
            if p.avg_response_days <= 7:   score += 20
            elif p.avg_response_days <= 14: score += 15
            elif p.avg_response_days <= 30: score += 10
            else: score += 3

            # Platform bonus (0–20)
            plt_bonus = {"intigriti": 20, "hackerone": 15, "yeswehack": 10, "bugcrowd": 10}
            score += plt_bonus.get(p.platform.lower(), 5)

            ranked.append({
                "program_id":        p.program_id,
                "program_name":      p.program_name,
                "platform":          p.platform,
                "roi_score":         score,
                "max_critical":      p.critical_max,
                "payout_reputation": p.payout_reputation,
                "avg_response_days": p.avg_response_days,
                "recommended":       score >= 60,
            })

        ranked.sort(key=lambda x: x["roi_score"], reverse=True)
        return ranked


# ══════════════════════════════════════════════════════════════════════
# ROI TRACKER
# ══════════════════════════════════════════════════════════════════════

class ROITracker:
    """
    Tracks all submissions and provides analytics on bounty earnings,
    acceptance rates, and estimation accuracy.
    Persists to JSON for use across sessions.
    """

    def __init__(self, storage_path: str = "./decepticon_submissions.json"):
        self.storage_path = storage_path
        self.submissions: list[SubmissionRecord] = []
        self._load()

    # ── CRUD ─────────────────────────────────────────────────────────

    def add_submission(self, record: SubmissionRecord):
        self.submissions.append(record)
        self._save()

    def update_status(self, report_id: str, status: str,
                      actual_payout: int = 0, notes: str = "") -> bool:
        for sub in self.submissions:
            if sub.report_id == report_id:
                sub.status = status
                if actual_payout > 0:
                    sub.actual_payout = actual_payout
                if status == "resolved" and not sub.resolved_at:
                    sub.resolved_at = datetime.now().isoformat()
                    submitted   = datetime.fromisoformat(sub.submitted_at)
                    resolved    = datetime.fromisoformat(sub.resolved_at)
                    sub.days_to_resolve = (resolved - submitted).days
                if notes:
                    sub.notes = notes
                self._save()
                return True
        return False

    def get_submission(self, report_id: str) -> Optional[SubmissionRecord]:
        return next((s for s in self.submissions if s.report_id == report_id), None)

    # ── ANALYTICS ────────────────────────────────────────────────────

    def weekly_report(self) -> dict:
        """Generate earnings + performance report for the last 7 days."""
        cutoff = datetime.now() - timedelta(days=7)
        week   = [s for s in self.submissions
                  if datetime.fromisoformat(s.submitted_at) >= cutoff]

        return {
            "period":           "last_7_days",
            "generated_at":     datetime.now().isoformat(),
            **self._compute_stats(week, label="week"),
            "by_platform":      self._by_platform(week),
            "by_severity":      self._by_severity(week),
            "by_vuln_type":     self._by_vuln_type(week),
            "estimation_accuracy": self._estimation_accuracy(week),
        }

    def all_time_report(self) -> dict:
        """Full all-time performance report."""
        return {
            "period":        "all_time",
            "generated_at":  datetime.now().isoformat(),
            **self._compute_stats(self.submissions, label="all"),
            "by_platform":   self._by_platform(self.submissions),
            "by_severity":   self._by_severity(self.submissions),
            "by_vuln_type":  self._by_vuln_type(self.submissions),
            "estimation_accuracy": self._estimation_accuracy(self.submissions),
            "top_programs":  self._top_programs(),
            "top_vuln_types": self._top_vuln_types(),
        }

    def submission_queue_summary(self, estimates: list[PayoutEstimate]) -> list[dict]:
        """Return sorted submission queue with ROI ranking."""
        queue = []
        for e in estimates:
            if e.expected_payout >= 200 and e.triage_confidence >= 0.65:
                queue.append({
                    "finding_id":       e.finding_id,
                    "title":            e.title,
                    "vuln_type":        e.vuln_type,
                    "severity":         e.severity,
                    "cvss":             e.cvss_score,
                    "confidence":       e.triage_confidence,
                    "expected_payout":  e.expected_payout,
                    "payout_range":     f"${e.payout_min:,}–${e.payout_max:,}",
                    "est_confidence":   e.estimate_confidence,
                    "days_to_payout":   e.estimated_days_to_payout,
                    "roi_score":        e.roi_score,
                    "multipliers":      e.multipliers_applied,
                })

        # Sort: highest expected_payout first, tie-break by confidence
        queue.sort(key=lambda x: (x["expected_payout"], x["confidence"]), reverse=True)
        for i, item in enumerate(queue):
            item["submit_priority"] = i + 1

        return queue

    def export_csv(self, path: str = "./decepticon_report.csv"):
        """Export all submissions to CSV."""
        if not self.submissions:
            return
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=asdict(self.submissions[0]).keys())
            writer.writeheader()
            for sub in self.submissions:
                writer.writerow(asdict(sub))

    # ── Private ──────────────────────────────────────────────────────

    def _compute_stats(self, subs: list[SubmissionRecord], label: str) -> dict:
        if not subs:
            return {f"total_submitted_{label}": 0}

        resolved  = [s for s in subs if s.status == "resolved"]
        paid      = [s for s in resolved if s.actual_payout > 0]
        dupes     = [s for s in subs if s.status == "duplicate"]
        triaged   = [s for s in subs if s.status == "triaged"]

        total_earned   = sum(s.actual_payout for s in paid)
        avg_resolution = (
            sum(s.days_to_resolve for s in resolved if s.days_to_resolve)
            / max(len([s for s in resolved if s.days_to_resolve]), 1)
        )

        return {
            f"total_submitted":    len(subs),
            f"total_earned":       total_earned,
            f"resolved_count":     len(resolved),
            f"paid_count":         len(paid),
            f"duplicate_count":    len(dupes),
            f"triaged_count":      len(triaged),
            f"acceptance_rate":    round(len(resolved) / max(len(subs), 1), 2),
            f"duplicate_rate":     round(len(dupes) / max(len(subs), 1), 2),
            f"avg_payout":         int(total_earned / max(len(paid), 1)),
            f"avg_resolution_days": round(avg_resolution, 1),
            f"best_single_payout": max((s.actual_payout for s in paid), default=0),
        }

    def _by_platform(self, subs: list[SubmissionRecord]) -> list[dict]:
        platforms = set(s.platform for s in subs)
        result    = []
        for plt in platforms:
            p_subs   = [s for s in subs if s.platform == plt]
            p_paid   = [s for s in p_subs if s.actual_payout > 0]
            result.append({
                "platform":       plt,
                "submitted":      len(p_subs),
                "earned":         sum(s.actual_payout for s in p_paid),
                "avg_payout":     int(sum(s.actual_payout for s in p_paid) / max(len(p_paid), 1)),
                "acceptance_rate": round(len([s for s in p_subs if s.status == "resolved"]) / max(len(p_subs), 1), 2),
            })
        return sorted(result, key=lambda x: x["earned"], reverse=True)

    def _by_severity(self, subs: list[SubmissionRecord]) -> list[dict]:
        result = []
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            s_subs = [s for s in subs if s.severity.upper() == sev]
            s_paid = [s for s in s_subs if s.actual_payout > 0]
            if s_subs:
                result.append({
                    "severity":   sev,
                    "count":      len(s_subs),
                    "earned":     sum(s.actual_payout for s in s_paid),
                    "avg_payout": int(sum(s.actual_payout for s in s_paid) / max(len(s_paid), 1)),
                })
        return result

    def _by_vuln_type(self, subs: list[SubmissionRecord]) -> list[dict]:
        vtypes = set(s.vuln_type for s in subs)
        result = []
        for vt in vtypes:
            vt_subs  = [s for s in subs if s.vuln_type == vt]
            vt_paid  = [s for s in vt_subs if s.actual_payout > 0]
            vt_dupes = [s for s in vt_subs if s.status == "duplicate"]
            result.append({
                "vuln_type":      vt,
                "count":          len(vt_subs),
                "earned":         sum(s.actual_payout for s in vt_paid),
                "duplicate_rate": round(len(vt_dupes) / max(len(vt_subs), 1), 2),
            })
        return sorted(result, key=lambda x: x["earned"], reverse=True)

    def _estimation_accuracy(self, subs: list[SubmissionRecord]) -> dict:
        compared = [s for s in subs
                    if s.estimated_payout > 0 and s.actual_payout > 0]
        if not compared:
            return {"samples": 0}

        errors = [abs(s.actual_payout - s.estimated_payout) / max(s.estimated_payout, 1)
                  for s in compared]
        avg_error = sum(errors) / len(errors)
        accurate  = sum(1 for e in errors if e <= 0.25)

        return {
            "samples":        len(compared),
            "avg_error_pct":  round(avg_error * 100, 1),
            "within_25pct":   round(accurate / len(compared), 2),
            "overestimated":  sum(1 for s in compared if s.estimated_payout > s.actual_payout),
            "underestimated": sum(1 for s in compared if s.estimated_payout < s.actual_payout),
        }

    def _top_programs(self) -> list[dict]:
        programs = set((s.program_id, s.program_name) for s in self.submissions)
        result   = []
        for pid, pname in programs:
            p_subs = [s for s in self.submissions if s.program_id == pid]
            earned = sum(s.actual_payout for s in p_subs if s.actual_payout > 0)
            result.append({"program": pname, "earned": earned, "submissions": len(p_subs)})
        return sorted(result, key=lambda x: x["earned"], reverse=True)[:5]

    def _top_vuln_types(self) -> list[dict]:
        by_type = self._by_vuln_type(self.submissions)
        return sorted(by_type, key=lambda x: x["earned"], reverse=True)[:5]

    def _load(self):
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path) as f:
                    data = json.load(f)
                self.submissions = [SubmissionRecord(**s) for s in data]
            except Exception:
                self.submissions = []

    def _save(self):
        with open(self.storage_path, "w") as f:
            json.dump([asdict(s) for s in self.submissions], f, indent=2)
