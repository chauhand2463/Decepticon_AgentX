"""
DECEPTICON — Auto-Triage & Scope Validator Feature Modules

AutoTriager    — False positive filtering + confidence scoring
ScopeValidator — Block out-of-scope targets before any scan
"""

import re
import json
import socket
import ipaddress
import requests
from datetime import datetime, timedelta
from typing import Optional
from dataclasses import dataclass, field, asdict


# ══════════════════════════════════════════════════════════════════════
# AUTO-TRIAGE MODULE
# ══════════════════════════════════════════════════════════════════════

@dataclass
class RawFinding:
    id:           str
    title:        str
    vuln_type:    str    # sqli, xss_stored, rce, ssrf, idor, etc.
    endpoint:     str
    severity:     str
    cvss_score:   float
    evidence:     str    # raw tool output
    affects_auth: bool   # True = requires authentication
    affects_others: bool # True = can impact other users
    tool_source:  str    # which tool found it: nmap, nuclei, sqlmap, manual
    steps:        list[str] = field(default_factory=list)
    extra:        dict    = field(default_factory=dict)


@dataclass
class TriageResult:
    finding_id:            str
    title:                 str
    vuln_type:             str
    triage_result:         str  # TRUE_POSITIVE, FALSE_POSITIVE, INFORMATIONAL, NEEDS_MANUAL
    confidence_score:      float
    confidence_reason:     str
    false_positive_reason: str
    platform_prediction:   str  # LIKELY_ACCEPTED, LIKELY_DUPLICATE, LIKELY_INFORMATIONAL
    recommended_severity:  str
    verified_impact:       str
    submit:                bool
    flags:                 list[str] = field(default_factory=list)


class AutoTriager:
    """
    Filters false positives and assigns confidence scores to raw findings.
    Prevents low-quality submissions that waste program goodwill.
    """

    # Vuln types that are ALWAYS false positives in these conditions
    FP_RULES = {
        "xss_reflected": [
            ("affects_others", False, "Reflected XSS only affecting attacker = self-XSS"),
        ],
        "csrf": [
            ("endpoint_contains", "/logout", "CSRF on logout is not a security risk"),
        ],
        "clickjacking": [
            ("always", True, "Clickjacking without sensitive actions = informational only"),
        ],
        "rate_limit": [
            ("endpoint_not_contains", "/login|/auth|/password|/otp|/2fa",
             "Rate limiting only impacts authentication endpoints"),
        ],
        "ssl_tls": [
            ("always", True, "SSL/TLS version issues = informational, rarely earns bounty"),
        ],
        "email_enumeration": [
            ("always", True, "Email enumeration on public login = usually excluded"),
        ],
        "missing_headers": [
            ("always", True, "Missing security headers alone = informational"),
        ],
        "spf_dmarc": [
            ("always", True, "SPF/DMARC without actual phishing impact = informational"),
        ],
    }

    # Scanner-only findings get automatic confidence penalty
    SCANNER_TOOLS = {"nmap", "nikto", "nuclei_auto", "burp_scanner", "zap_scanner"}

    # High-confidence vuln types (when properly exploited)
    HIGH_CONFIDENCE_TYPES = {
        "rce":                  0.92,
        "sqli":                 0.88,
        "auth_bypass":          0.87,
        "account_takeover":     0.95,
        "ssrf":                 0.82,
        "xxe":                  0.80,
        "idor":                 0.78,
        "privilege_escalation": 0.85,
        "open_s3_bucket":       0.90,
        "default_credentials":  0.93,
        "git_exposure":         0.92,
        "env_file_exposure":    0.95,
    }

    # Commonly duplicated findings (confidence penalty)
    COMMON_DUPLICATES = [
        "reflected xss in search",
        "cors misconfiguration",
        "missing x-frame-options",
        "missing content-security-policy",
        "open redirect",
        "host header injection",
        "username enumeration",
        "email enumeration login",
    ]

    def triage(self, finding: RawFinding) -> TriageResult:
        """Main triage function. Returns a TriageResult with decision."""
        flags  = []
        fp_reason = ""

        # Step 1: Check hard false positive rules
        fp_check = self._check_false_positive(finding)
        if fp_check:
            return TriageResult(
                finding_id=finding.id,
                title=finding.title,
                vuln_type=finding.vuln_type,
                triage_result="FALSE_POSITIVE",
                confidence_score=0.0,
                confidence_reason="Matched hard false-positive rule",
                false_positive_reason=fp_check,
                platform_prediction="LIKELY_INFORMATIONAL",
                recommended_severity="INFO",
                verified_impact="None — false positive",
                submit=False,
                flags=["FP_HARD_RULE"],
            )

        # Step 2: Calculate base confidence
        base_confidence = self._base_confidence(finding)

        # Step 3: Apply boosters and reducers
        confidence, reasons = self._adjust_confidence(finding, base_confidence)

        # Step 4: Determine triage result
        triage_result = self._classify(finding, confidence)

        # Step 5: Check for likely duplicates
        dup_flag = self._check_duplicate_pattern(finding)
        if dup_flag:
            confidence = max(0, confidence - 0.15)
            flags.append("LIKELY_DUPLICATE_PATTERN")

        # Step 6: Predict platform acceptance
        prediction = self._predict_acceptance(finding, triage_result)

        # Step 7: Verify impact
        impact = self._assess_impact(finding)

        # Step 8: Determine submit
        submit = (
            triage_result == "TRUE_POSITIVE"
            and confidence >= 0.65
            and prediction != "LIKELY_INFORMATIONAL"
        )

        return TriageResult(
            finding_id=finding.id,
            title=finding.title,
            vuln_type=finding.vuln_type,
            triage_result=triage_result,
            confidence_score=round(confidence, 2),
            confidence_reason=" | ".join(reasons),
            false_positive_reason=fp_reason,
            platform_prediction=prediction,
            recommended_severity=self._recommend_severity(finding, confidence),
            verified_impact=impact,
            submit=submit,
            flags=flags,
        )

    def triage_batch(self, findings: list[RawFinding]) -> dict:
        """Triage a list of findings and return summary."""
        results = [self.triage(f) for f in findings]
        accepted    = [r for r in results if r.submit]
        rejected    = [r for r in results if not r.submit]
        manual      = [r for r in results if r.triage_result == "NEEDS_MANUAL"]

        return {
            "triage_timestamp": datetime.now().isoformat(),
            "total_input":      len(findings),
            "accepted":         len(accepted),
            "rejected":         len(rejected),
            "needs_manual":     len(manual),
            "acceptance_rate":  round(len(accepted)/max(len(findings),1), 2),
            "findings": [asdict(r) for r in accepted],
            "rejected_findings": [asdict(r) for r in rejected],
            "manual_queue":     [asdict(r) for r in manual],
        }

    # ── Private helpers ──────────────────────────────────────────────

    def _check_false_positive(self, f: RawFinding) -> Optional[str]:
        """Returns FP reason string if finding is a confirmed false positive."""
        vt = f.vuln_type.lower()

        # Hard FP: self-XSS
        if "xss" in vt and not f.affects_others:
            return "Self-XSS — only affects the attacker's own session"

        # Hard FP: CSRF on logout
        if vt == "csrf" and "logout" in f.endpoint.lower():
            return "CSRF on logout endpoint has no security impact"

        # Hard FP: Scanner-only with no manual verification
        if f.tool_source in self.SCANNER_TOOLS and not f.steps:
            return f"Scanner-only finding from {f.tool_source} with no manual PoC"

        # Hard FP: Missing headers without exploit chain
        if vt in ("missing_headers", "clickjacking", "ssl_tls", "spf_dmarc",
                  "email_enumeration", "rate_limit") and not f.affects_others:
            return f"{vt} without demonstrable impact on other users"

        # Hard FP: Version disclosure with no exploitable CVE
        if vt == "info_disclosure" and f.cvss_score < 3.0 and not f.affects_others:
            return "Information disclosure below CVSS 3.0 with no impact on others"

        return None

    def _base_confidence(self, f: RawFinding) -> float:
        """Start with type-based base confidence."""
        vt = f.vuln_type.lower()
        base = self.HIGH_CONFIDENCE_TYPES.get(vt, 0.60)

        # Scanner-only penalty
        if f.tool_source in self.SCANNER_TOOLS:
            base -= 0.15

        # Manual finding bonus
        if f.tool_source == "manual":
            base += 0.10

        return min(max(base, 0.0), 1.0)

    def _adjust_confidence(self, f: RawFinding, base: float) -> tuple[float, list[str]]:
        """Apply contextual boosters and reducers."""
        confidence = base
        reasons    = [f"Base ({f.vuln_type}): {base:.2f}"]

        # Boosters
        if f.evidence and len(f.evidence) > 100:
            confidence += 0.05
            reasons.append("+0.05 tool evidence present")

        if f.affects_others:
            confidence += 0.08
            reasons.append("+0.08 affects other users")

        if not f.affects_auth:
            confidence += 0.10
            reasons.append("+0.10 no auth required")

        if f.cvss_score >= 9.0:
            confidence += 0.08
            reasons.append(f"+0.08 CVSS {f.cvss_score}")
        elif f.cvss_score >= 7.0:
            confidence += 0.05
            reasons.append(f"+0.05 CVSS {f.cvss_score}")

        if len(f.steps) >= 3:
            confidence += 0.05
            reasons.append("+0.05 clear reproduction steps")

        # Reducers
        if f.affects_auth:
            confidence -= 0.05
            reasons.append("-0.05 requires authentication")

        if not f.evidence:
            confidence -= 0.20
            reasons.append("-0.20 no evidence provided")

        if f.cvss_score < 4.0:
            confidence -= 0.10
            reasons.append(f"-0.10 low CVSS {f.cvss_score}")

        return round(min(max(confidence, 0.0), 1.0), 3), reasons

    def _classify(self, f: RawFinding, confidence: float) -> str:
        if confidence >= 0.65:
            return "TRUE_POSITIVE"
        elif confidence >= 0.40:
            return "NEEDS_MANUAL"
        elif confidence >= 0.20:
            return "INFORMATIONAL"
        else:
            return "FALSE_POSITIVE"

    def _check_duplicate_pattern(self, f: RawFinding) -> bool:
        title_lower = f.title.lower()
        return any(pattern in title_lower for pattern in self.COMMON_DUPLICATES)

    def _predict_acceptance(self, f: RawFinding, triage_result: str) -> str:
        if triage_result == "FALSE_POSITIVE":
            return "LIKELY_REJECTED"
        always_accepted = {"rce","sqli","auth_bypass","account_takeover","ssrf",
                           "idor","open_s3_bucket","default_credentials","env_file_exposure"}
        if f.vuln_type.lower() in always_accepted:
            return "LIKELY_ACCEPTED"
        if f.vuln_type.lower() in {"missing_headers","clickjacking","ssl_tls","spf_dmarc"}:
            return "LIKELY_INFORMATIONAL"
        return "LIKELY_ACCEPTED" if f.cvss_score >= 7.0 else "LIKELY_INFORMATIONAL"

    def _assess_impact(self, f: RawFinding) -> str:
        impact_map = {
            "sqli":                "Full database read/write access",
            "rce":                 "Remote command execution on server",
            "ssrf":                "Access to internal network services",
            "idor":                "Unauthorized access to other users' data",
            "xss_stored":          "Session hijacking for any visitor",
            "auth_bypass":         "Full account access without credentials",
            "open_s3_bucket":      "Public read access to all stored files",
            "default_credentials": "Admin-level access to service",
            "env_file_exposure":   "Credentials and secrets leak",
            "git_exposure":        "Full source code and history disclosure",
            "lfi":                 "Read arbitrary files from server",
            "path_traversal":      "Read files outside web root",
        }
        return impact_map.get(f.vuln_type.lower(), f"Impact depends on context of {f.vuln_type}")

    def _recommend_severity(self, f: RawFinding, confidence: float) -> str:
        if confidence < 0.65:
            return "LOW"
        if f.cvss_score >= 9.0:   return "CRITICAL"
        elif f.cvss_score >= 7.0: return "HIGH"
        elif f.cvss_score >= 4.0: return "MEDIUM"
        else:                     return "LOW"


# ══════════════════════════════════════════════════════════════════════
# SCOPE VALIDATOR MODULE
# ══════════════════════════════════════════════════════════════════════

# CDN and cloud provider IP ranges (simplified — expand in production)
KNOWN_CDN_RANGES = [
    "104.16.0.0/12",   # Cloudflare
    "172.64.0.0/13",   # Cloudflare
    "13.32.0.0/15",    # AWS CloudFront
    "99.84.0.0/16",    # AWS CloudFront
    "151.101.0.0/16",  # Fastly
    "23.235.32.0/20",  # Fastly
]

# SaaS domains that should NEVER be tested
BLOCKED_SAAS_DOMAINS = [
    "zendesk.com", "salesforce.com", "hubspot.com", "intercom.io",
    "stripe.com", "twilio.com", "sendgrid.com", "mailchimp.com",
    "cloudflare.com", "amazonaws.com", "azure.com", "googleapis.com",
    "fastly.net", "akamaiedge.net", "edgekey.net",
]

# Vuln types commonly excluded across programs
COMMONLY_EXCLUDED = {
    "self_xss", "clickjacking", "missing_headers", "ssl_tls_version",
    "rate_limit_non_auth", "spf_dmarc", "email_enumeration",
    "social_engineering", "physical_attack", "dos_ddos",
}


class ScopeValidator:
    """
    Validates targets and vulnerability classes against program scope.
    Returns ALLOW/BLOCK/CONFIRM for each target before any scanning begins.
    """

    SCOPE_CACHE_TTL_HOURS = 24

    def __init__(self):
        self._scope_cache: dict = {}

    # ── Core validation ──────────────────────────────────────────────

    def validate_target(self, target: str, scope: dict) -> dict:
        """
        Validate a single target against program scope.
        Returns {"decision": "ALLOW|BLOCK|CONFIRM", "reason": str, ...}
        """
        # Step 1: Check explicit out-of-scope list
        for oos in scope.get("out_scope", []):
            ident = oos.get("asset_identifier", "")
            if self._matches(target, ident):
                return {
                    "target":   target,
                    "decision": "BLOCK",
                    "reason":   f"Explicitly out-of-scope: {ident}",
                    "block_type": "OUT_OF_SCOPE",
                }

        # Step 2: Check against in-scope list
        matched_scope = None
        for ins in scope.get("in_scope", []):
            ident = ins.get("asset_identifier", "")
            if self._matches(target, ident):
                matched_scope = ins
                break

        if not matched_scope:
            return {
                "target":   target,
                "decision": "BLOCK",
                "reason":   "Target not found in in-scope list",
                "block_type": "NOT_IN_SCOPE",
            }

        # Step 3: Check third-party services
        tp_check = self._check_third_party(target)
        if tp_check:
            return {
                "target":   target,
                "decision": "BLOCK",
                "reason":   tp_check,
                "block_type": "THIRD_PARTY",
            }

        # Step 4: Check CDN
        cdn_check = self._check_cdn(target)
        if cdn_check:
            return {
                "target":   target,
                "decision": "CONFIRM",
                "reason":   f"Target resolves to CDN — confirm CDN is in scope: {cdn_check}",
                "block_type": "CDN_WARNING",
                "in_scope_match": matched_scope.get("asset_identifier"),
            }

        return {
            "target":          target,
            "decision":        "ALLOW",
            "reason":          f"Matches in-scope: {matched_scope.get('asset_identifier')}",
            "in_scope_match":  matched_scope.get("asset_identifier"),
            "bounty_eligible": matched_scope.get("eligible_for_bounty", True),
            "max_severity":    matched_scope.get("max_severity", "CRITICAL"),
        }

    def validate_vuln_type(self, vuln_type: str, program_exclusions: list[str]) -> dict:
        """Check if a vulnerability class is allowed for this program."""
        vt = vuln_type.lower().replace(" ", "_").replace("-", "_")

        # Universal exclusions
        if vt in COMMONLY_EXCLUDED:
            return {
                "vuln_type": vuln_type,
                "decision":  "BLOCK",
                "reason":    f"{vuln_type} is commonly excluded across most programs",
            }

        # Program-specific exclusions
        exclusions_lower = [e.lower().replace(" ", "_") for e in program_exclusions]
        if vt in exclusions_lower:
            return {
                "vuln_type": vuln_type,
                "decision":  "BLOCK",
                "reason":    f"{vuln_type} is explicitly excluded by this program",
            }

        return {
            "vuln_type": vuln_type,
            "decision":  "ALLOW",
            "reason":    "Vulnerability type is in scope",
        }

    def validate_batch(self, targets: list[str], scope: dict,
                       vuln_types: list[str] = None) -> dict:
        """Validate a full list of targets and vuln types."""
        target_results  = [self.validate_target(t, scope) for t in targets]
        allowed_targets = [r["target"] for r in target_results if r["decision"] == "ALLOW"]
        blocked_targets = [r for r in target_results if r["decision"] == "BLOCK"]
        confirm_needed  = [r for r in target_results if r["decision"] == "CONFIRM"]

        vuln_results = []
        if vuln_types:
            exclusions = scope.get("excluded_vuln_types", [])
            vuln_results = [self.validate_vuln_type(vt, exclusions) for vt in vuln_types]

        return {
            "guardian_timestamp":  datetime.now().isoformat(),
            "program":             scope.get("program", ""),
            "platform":            scope.get("platform", ""),
            "scope_valid":         len(allowed_targets) > 0,
            "approved_for_testing": allowed_targets,
            "blocked_targets":     blocked_targets,
            "confirm_needed":      confirm_needed,
            "vuln_type_decisions": vuln_results,
            "warnings": [r["reason"] for r in confirm_needed],
            "total_approved":      len(allowed_targets),
            "total_blocked":       len(blocked_targets),
        }

    # ── Helpers ──────────────────────────────────────────────────────

    def _matches(self, target: str, scope_entry: str) -> bool:
        """Check if target matches a scope entry (wildcard or exact)."""
        target = target.lower().strip()
        scope_entry = scope_entry.lower().strip()

        # Strip protocols
        target = re.sub(r"https?://", "", target).rstrip("/")
        scope_entry = re.sub(r"https?://", "", scope_entry).rstrip("/")

        # Wildcard match: *.example.com
        if scope_entry.startswith("*."):
            base = scope_entry[2:]
            # *.example.com matches sub.example.com but NOT example.com or a.b.example.com
            return (target.endswith("." + base) and
                    target.count(".") == base.count(".") + 1)

        # CIDR match
        if "/" in scope_entry:
            try:
                return ipaddress.ip_address(target) in ipaddress.ip_network(scope_entry, strict=False)
            except ValueError:
                pass

        # Exact match
        return target == scope_entry

    def _check_third_party(self, target: str) -> Optional[str]:
        """Returns block reason if target is a third-party SaaS."""
        target_lower = target.lower()
        for blocked in BLOCKED_SAAS_DOMAINS:
            if target_lower.endswith(blocked) or target_lower == blocked:
                return f"Third-party SaaS domain: {blocked} — never in scope"
        return None

    def _check_cdn(self, target: str) -> Optional[str]:
        """Returns CDN name if target resolves to known CDN IP."""
        try:
            ip = socket.gethostbyname(target)
            for cidr in KNOWN_CDN_RANGES:
                if ipaddress.ip_address(ip) in ipaddress.ip_network(cidr, strict=False):
                    return f"Resolves to CDN IP {ip} in range {cidr}"
        except Exception:
            pass
        return None

    def is_cache_fresh(self, cache_key: str) -> bool:
        """Check if scope cache is within TTL."""
        if cache_key not in self._scope_cache:
            return False
        cached_at = self._scope_cache[cache_key].get("cached_at")
        if not cached_at:
            return False
        age = datetime.now() - datetime.fromisoformat(cached_at)
        return age < timedelta(hours=self.SCOPE_CACHE_TTL_HOURS)

    def cache_scope(self, key: str, scope: dict):
        self._scope_cache[key] = {**scope, "cached_at": datetime.now().isoformat()}

    def get_cached_scope(self, key: str) -> Optional[dict]:
        if self.is_cache_fresh(key):
            return self._scope_cache[key]
        return None
