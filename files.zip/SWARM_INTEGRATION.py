"""
DECEPTICON — Complete Bug Bounty Swarm Integration
Shows exactly how all 9 agents wire together in LangGraph.

Agent roster:
  Existing:  PHANTOM (planner), SHADOW (recon), ORACLE (researcher),
             BREACH (access), CIPHER (summary)
  New:       BOUNTY (coordinator), SCOUT (bb recon), TRIAGE (fp filter),
             GUARDIAN (scope), ANALYST (roi)

Run:  python frontend/cli/cli.py  (same as before — new agents auto-loaded)
"""

# ─────────────────────────────────────────────────────────────────────
# STEP 1 — Import all prompts
# ─────────────────────────────────────────────────────────────────────

from src.utils.agents.prompts import (           # existing
    PLANNER_SYSTEM_PROMPT,
    RECON_SYSTEM_PROMPT,
    ACCESS_SYSTEM_PROMPT,
    RESEARCHER_SYSTEM_PROMPT,
    SUMMARY_SYSTEM_PROMPT,
)
from bounty.bounty_agent_prompt import (          # new from previous package
    BOUNTY_AGENT_PROMPT,
)
from agents.bounty_prompts import (               # this package
    SCOUT_AGENT_PROMPT,
    TRIAGE_AGENT_PROMPT,
    GUARDIAN_AGENT_PROMPT,
    ANALYST_AGENT_PROMPT,
)

# ─────────────────────────────────────────────────────────────────────
# STEP 2 — Import feature modules
# ─────────────────────────────────────────────────────────────────────

from features.recon           import SubdomainDiscovery, EndpointDiscovery
from features.triage_and_scope import AutoTriager, ScopeValidator, RawFinding
from features.payout_roi      import PayoutEstimator, ROITracker, ProgramPayoutTable, SubmissionRecord
from bounty.platforms         import BountyManager
from bounty.scorer_reporter   import CVSSScorer, ReportGenerator, Finding

# ─────────────────────────────────────────────────────────────────────
# STEP 3 — Build the extended LangGraph state
# ─────────────────────────────────────────────────────────────────────

from typing import TypedDict, Annotated, List, Optional
from langgraph.graph import add_messages

class BountyPentestState(TypedDict):
    # Core swarm messages
    messages: Annotated[list, add_messages]

    # Mission metadata
    mission_type:   str       # PENTEST | BUG_BOUNTY | RECON_ONLY
    target:         str
    platform:       str       # hackerone | bugcrowd | intigriti | yeswehack
    program_id:     str
    phase:          str       # scope | recon | scan | triage | report | submit

    # GUARDIAN output
    validated_scope:    dict
    approved_targets:   List[str]
    excluded_vuln_types: List[str]

    # SCOUT output
    subdomains:         List[dict]
    live_hosts:         List[dict]
    endpoints:          List[dict]
    js_secrets:         List[dict]
    potential_takeovers: List[dict]

    # ORACLE / SHADOW output
    raw_findings:       List[dict]

    # TRIAGE output
    triaged_findings:   List[dict]
    rejected_findings:  List[dict]

    # ANALYST output
    submission_queue:   List[dict]
    program_rankings:   List[dict]

    # BOUNTY / CIPHER output
    submitted_reports:  List[dict]
    final_report:       str


# ─────────────────────────────────────────────────────────────────────
# STEP 4 — Create all agents
# ─────────────────────────────────────────────────────────────────────

from langgraph.prebuilt import create_react_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
import json, os

async def create_full_bounty_swarm(llm):
    """
    Creates all 9 agents with their tools and prompts.
    Returns dict of {agent_name: compiled_agent}
    """

    # Load MCP tools from config
    base = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base, "mcp_config.json")
    with open(config_path) as f:
        mcp_config = json.load(f)

    async def get_tools(agent_key: str):
        servers = mcp_config.get(agent_key, {})
        if not servers or "note" in servers:
            return []
        client = MultiServerMCPClient(servers)
        return await client.get_tools()

    nmap_tools      = await get_tools("recon_agent")
    nuclei_tools    = await get_tools("researcher_agent")
    access_tools    = await get_tools("access_agent")

    # ── Existing pentest agents ──────────────────────────────────────
    phantom = create_react_agent(llm, tools=[],
                                 state_modifier=PLANNER_SYSTEM_PROMPT)

    shadow  = create_react_agent(llm, tools=nmap_tools,
                                 state_modifier=RECON_SYSTEM_PROMPT)

    oracle  = create_react_agent(llm, tools=nuclei_tools,
                                 state_modifier=RESEARCHER_SYSTEM_PROMPT)

    breach  = create_react_agent(llm, tools=access_tools,
                                 state_modifier=ACCESS_SYSTEM_PROMPT)

    cipher  = create_react_agent(llm, tools=[],
                                 state_modifier=SUMMARY_SYSTEM_PROMPT)

    # ── New bug bounty agents ────────────────────────────────────────
    bounty   = create_react_agent(llm, tools=[],
                                  state_modifier=BOUNTY_AGENT_PROMPT)

    scout    = create_react_agent(llm, tools=nmap_tools,   # reuses nmap for live host check
                                  state_modifier=SCOUT_AGENT_PROMPT)

    triage   = create_react_agent(llm, tools=[],
                                  state_modifier=TRIAGE_AGENT_PROMPT)

    guardian = create_react_agent(llm, tools=[],
                                  state_modifier=GUARDIAN_AGENT_PROMPT)

    analyst  = create_react_agent(llm, tools=[],
                                  state_modifier=ANALYST_AGENT_PROMPT)

    return {
        # Pentest swarm
        "phantom": phantom,
        "shadow":  shadow,
        "oracle":  oracle,
        "breach":  breach,
        "cipher":  cipher,
        # Bug bounty swarm
        "bounty":   bounty,
        "scout":    scout,
        "triage":   triage,
        "guardian": guardian,
        "analyst":  analyst,
    }


# ─────────────────────────────────────────────────────────────────────
# STEP 5 — LangGraph routing logic
# ─────────────────────────────────────────────────────────────────────

from langgraph.graph import StateGraph, END

def route_by_mission(state: BountyPentestState) -> str:
    """Route to correct first agent based on mission type."""
    mt = state.get("mission_type", "PENTEST")
    if mt == "BUG_BOUNTY":
        return "guardian"    # Bug bounty always starts with scope validation
    elif mt == "RECON_ONLY":
        return "scout"
    else:
        return "phantom"     # Standard pentest starts with planner


def route_after_guardian(state: BountyPentestState) -> str:
    """After scope validation, go to recon."""
    scope = state.get("validated_scope", {})
    if not scope.get("scope_valid", False):
        return END           # No valid scope = halt
    mt = state.get("mission_type", "PENTEST")
    return "scout" if mt == "BUG_BOUNTY" else "shadow"


def route_after_triage(state: BountyPentestState) -> str:
    """After triage, go to analyst for ROI scoring."""
    findings = state.get("triaged_findings", [])
    if not findings:
        return "cipher"      # Nothing to submit, just report
    return "analyst"


def route_after_analyst(state: BountyPentestState) -> str:
    """After ROI analysis, go to bounty coordinator for submission."""
    queue = state.get("submission_queue", [])
    if not queue:
        return "cipher"
    return "bounty"


def build_bounty_graph(agents: dict) -> StateGraph:
    """Build the complete LangGraph state machine."""
    graph = StateGraph(BountyPentestState)

    # Add all nodes
    for name, agent in agents.items():
        graph.add_node(name, agent)

    # ── Routing edges ────────────────────────────────────────────────

    # Entry point
    graph.set_conditional_entry_point(
        route_by_mission,
        {"guardian": "guardian", "scout": "scout", "phantom": "phantom"}
    )

    # Pentest path
    graph.add_edge("phantom", "shadow")
    graph.add_edge("shadow",  "oracle")
    graph.add_edge("oracle",  "breach")
    graph.add_edge("breach",  "cipher")
    graph.add_edge("cipher",  END)

    # Bug bounty path
    graph.add_conditional_edges("guardian", route_after_guardian,
                                 {"scout": "scout", END: END})
    graph.add_edge("scout",   "oracle")      # SCOUT findings → ORACLE scans
    graph.add_edge("oracle",  "triage")      # Raw findings → TRIAGE
    graph.add_conditional_edges("triage", route_after_triage,
                                 {"analyst": "analyst", "cipher": "cipher"})
    graph.add_conditional_edges("analyst", route_after_analyst,
                                 {"bounty": "bounty", "cipher": "cipher"})
    graph.add_edge("bounty",  "cipher")      # After submission, generate report
    graph.add_edge("cipher",  END)

    return graph.compile()


# ─────────────────────────────────────────────────────────────────────
# STEP 6 — Usage examples
# ─────────────────────────────────────────────────────────────────────

"""
EXAMPLE 1: Full bug bounty operation
─────────────────────────────────────
result = await graph.ainvoke({
    "messages": [HumanMessage(content=(
        "Run a full bug bounty operation on HackerOne program 'acme-corp'. "
        "Enumerate all subdomains, find vulnerabilities, triage findings, "
        "estimate payouts and submit the best ones."
    ))],
    "mission_type": "BUG_BOUNTY",
    "platform":     "hackerone",
    "program_id":   "acme-corp",
})

EXAMPLE 2: Scope check only
─────────────────────────────
result = await graph.ainvoke({
    "messages": [HumanMessage(content=(
        "Validate whether api.acme.com and staging.acme.com are in scope "
        "for HackerOne program 'acme-corp'."
    ))],
    "mission_type": "BUG_BOUNTY",
    "platform":     "hackerone",
    "program_id":   "acme-corp",
    "phase":        "scope",
})

EXAMPLE 3: Standard pentest (existing behavior unchanged)
──────────────────────────────────────────────────────────
result = await graph.ainvoke({
    "messages": [HumanMessage(content="Scan 192.168.1.1 for vulnerabilities")],
    "mission_type": "PENTEST",
    "target":       "192.168.1.1",
})

EXAMPLE 4: Triage only (from CLI)
───────────────────────────────────
DECEPTICON > triage the nuclei findings from my last scan
→ TRIAGE agent runs, filters false positives, returns confidence scores

EXAMPLE 5: ROI report
───────────────────────
DECEPTICON > show me my bug bounty earnings and best programs
→ ANALYST agent reads ROITracker storage, generates weekly report
"""


# ─────────────────────────────────────────────────────────────────────
# STEP 7 — Direct module usage (without swarm)
# ─────────────────────────────────────────────────────────────────────

"""
# Subdomain discovery standalone
discovery = SubdomainDiscovery("example.com")
results   = discovery.run_all()
print(f"Found {results['total_found']} subdomains, {results['live_count']} live")

# Endpoint discovery standalone
ep_disc  = EndpointDiscovery("https://api.example.com")
ep_data  = ep_disc.run_all()
print(f"JS secrets: {ep_data['js_analysis']['secrets_found']}")

# Scope validation standalone
validator = ScopeValidator()
scope     = manager.fetch_scope("hackerone", "acme-corp")
decision  = validator.validate_batch(["api.acme.com", "cdn.cloudflare.com"], scope)
print(decision)

# Triage standalone
triager  = AutoTriager()
finding  = RawFinding(
    id="F001", title="SQL Injection in /api/search",
    vuln_type="sqli", endpoint="/api/search?q=",
    severity="CRITICAL", cvss_score=9.8, evidence="sqlmap output...",
    affects_auth=False, affects_others=True, tool_source="sqlmap",
    steps=["1. Navigate to /api/search?q=test", "2. Append ' OR 1=1--", "3. Observe DB dump"]
)
result = triager.triage(finding)
print(f"Triage: {result.triage_result} | Confidence: {result.confidence_score}")

# Payout estimation standalone
estimator = PayoutEstimator()
program   = ProgramPayoutTable(
    program_id="acme-corp", platform="hackerone", program_name="Acme Corp",
    critical_min=3000, critical_max=15000,
    high_min=1000, high_max=5000,
    medium_min=300, medium_max=1500,
    payout_reputation="AVERAGE"
)
estimate = estimator.estimate(
    finding_id="F001", title="SQL Injection...",
    vuln_type="sqli", severity="CRITICAL", cvss_score=9.8,
    triage_confidence=0.92, platform="hackerone", program=program,
    context={"auth_required": False, "affects_all_users": True}
)
print(f"Expected payout: ${estimate.expected_payout:,} (confidence: {estimate.estimate_confidence})")

# ROI tracker
tracker = ROITracker("./my_submissions.json")
tracker.add_submission(SubmissionRecord(
    report_id="R001", finding_id="F001", title="SQL Injection...",
    platform="hackerone", program_id="acme-corp", program_name="Acme Corp",
    vuln_type="sqli", severity="CRITICAL", cvss_score=9.8,
    submitted_at=datetime.now().isoformat(),
    estimated_payout=estimate.expected_payout
))
# Later, when resolved:
tracker.update_status("R001", "resolved", actual_payout=8500)
print(tracker.weekly_report())
"""
